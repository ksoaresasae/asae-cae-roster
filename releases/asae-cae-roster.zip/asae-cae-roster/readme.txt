=== ASAE CAE Roster ===
Contributors: keithmsoares
Tags: asae, cae, roster, wicket
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 8.0
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Pull active CAEs from Wicket and render them as a paginated, searchable, alphabetically-organized public roster.

== Description ==

ASAE CAE Roster pulls the current list of Certified Association Executives (CAEs) from a Wicket member-data instance and caches them in the local WordPress database. A nightly sync (default 02:00 local time) keeps the cache current. The public roster is rendered with the `[asae_cae_roster]` shortcode and includes:

* A-Z letter navigation with inactive letters disabled
* First/last name search
* Pagination within each letter section (default 20 per page)
* Each entry shows photo, full name with credentials, job title, employing organization, and city/state

The plugin is built to be a low-priority Wicket consumer: failed syncs revert to the prior good snapshot, per-run request budgets cap impact on the upstream API, and an admin "Test Connection" button validates credentials without running a full sync.

== Installation ==

1. Upload the `asae-cae-roster` folder to `/wp-content/plugins/`.
2. Activate the plugin via the WordPress Plugins screen.
3. Go to **ASAE → CAE Roster → Settings** and enter the Wicket Base URL, HMAC Secret, and Person UUID.
4. Click **Test Connection** to confirm credentials, then **Save Settings**.
5. Click **Sync Now** on the Roster tab to pull initial data, or wait for the scheduled run.
6. Add `[asae_cae_roster]` to any public page or post.

== Changelog ==

= 1.0.1 =
* **Public roster colors now follow the active theme.** Previously every link, button, focus ring, letter-nav pill, pagination control, and current-state highlight in `assets/css/roster.css` had `#2271b1` (WordPress admin blue) hardcoded. Replaced with `var(--nv-primary-accent, #2271b1)` so the Neve theme renders in the site's brand color (e.g. ASAE's rust orange `#bd491e`) and other themes fall back to blue. The Search "Clear" link drops its explicit `color` rule entirely so it inherits the theme's normal anchor styling. Hover states use `filter: brightness(0.85)` (submit button) or `brightness(0.95)` (letter / pagination nav) instead of hardcoded darker blues, so the darken effect works regardless of base color. Mirrors the same fix shipped in asae-news-releases v0.2.3.
* Admin styling (`assets/css/admin.css`) is unchanged — admin UI uses WordPress admin colors by design.

= 1.0.0 =
First major release. Followed a full security audit (SQL injection, XSS, CSRF, authorization, SSRF, JWT/HMAC handling, deserialization, file inclusion, secrets exposure, GitHub updater integrity, IDORs, uninstall safety) and a full WCAG 2.2 Level AA accessibility audit covering both the public roster shortcode and the admin UI. Net result: 0 critical/high security findings; 1 high accessibility finding (a single contrast value 0.04 below the AA threshold), 3 medium, and a number of low / informational items addressed below. Detailed audit notes retained internally.

Security fixes
* Test Connection now validates the base_url through esc_url_raw with an explicit http/https scheme allowlist before signing a JWT — closes a low-risk authenticated SSRF / credential-leak vector where a tampered admin form could route the JWT (signed with the configured HMAC secret) at an arbitrary host.
* GitHub updater now host-allowlists the release asset URL against github.com / codeload.github.com / objects.githubusercontent.com before handing it to WP's auto-updater. A compromised release JSON couldn't redirect the updater at an attacker-controlled host without compromising GitHub itself.
* Fixed the GitHub updater's negative-cache sentinel: a failed lookup was being stored as null, which is indistinguishable from "transient missing" when read back via get_transient. Now stores array('failed' => 1) so the 1-hour negative cache actually holds, and the API isn't re-hit on every page load after a transient failure.

Accessibility fixes
* Disabled letter-nav and pagination items: color bumped from #6c6f73 (~4.46:1 against white — fails WCAG AA by 0.04) to #646970 (~4.69:1 — passes AA). Net visual change is essentially imperceptible; the AT-relevant fix is in the contrast ratio.
* Time-of-day hour/minute inputs are now wrapped in a <fieldset> with a screen-reader-only <legend> "Time of day (24-hour)". Sighted users see the existing "Time of day" row label unchanged; AT users now hear the grouping label before the two number inputs instead of "Hour, edit" with no surrounding context.
* Dry-run results container is no longer a live region (aria-live="polite" aria-atomic="false" removed). The small status span above already announces "X records loaded" via role=status, and replaying the entire 50-row table + diagnostic disclosure as live-region appends was producing a noisy multi-second screen-reader announcement.
* AJAX error path now surfaces server-supplied messages on non-2xx responses. Previously a 403 "Insufficient permissions." reply was being collapsed into a generic "could not save" string; the user now sees the actual reason. Implementation: a new readJsonResponse() helper that parses the JSON body even on non-2xx and only throws when there's no usable error payload to fall back on.

= 0.0.20 =
* Pagination is now also rendered at the top of the listing, just under the "Showing X - Y of Z" summary line, in addition to its existing position at the bottom. The bottom render_pagination() is unchanged. render_pagination() already self-suppresses on single-page results, so single-page views still don't show any pagination at all.
* Card location line now forces ALL CAPS on the state/province value regardless of how Wicket stored it ("MD" stays "MD", "Maryland" becomes "MARYLAND", "Ontario" becomes "ONTARIO"). Matches the dropdown's case treatment so the visual language for state values is consistent everywhere it appears.
* Search form label changed from "Search by name" to "Search by Name" for consistency with the title-cased City and State / Province field labels.

= 0.0.19 =
* State / Province dropdown: country options are now visually distinct from their constituent states/provinces. Two layers: (1) state labels are indented with leading non-breaking spaces — works in every browser since it's part of the label text, not CSS — making the country→state hierarchy obvious at a glance; (2) country options additionally render in italic and a slightly muted (#50575e — 7:1 contrast on white, well above WCAG AA) grey in browsers that honor CSS on <option> elements (Chrome and Edge fully; Firefox color only; Safari mostly ignored). The indentation is the primary distinguisher; the styling is layered reinforcement.
* Empty-state message now reports which filters were tried. Previously: "No CAEs match your search." — opaque when you'd combined name + city + state. Now: "No CAEs match search for: name "smi", city "an", state "NY"". Reuses the same describe_filters() helper that builds the results-summary line above the listing, so the wording stays consistent in both places.

= 0.0.18 =
* Diagnostic: replaced the v0.0.13 "Address attribute keys" row (which only fired when type === 'addresses' was actually present in `included` — silent otherwise) with an "Included resources" table that always renders inside Diagnostic detail. Each row shows the resource type, count of resources of that type in the response, and the attribute keys of the first instance. If `included` is empty or absent, the table renders "(no included resources in response)" so we can still tell. This is to figure out what type name Wicket is using for sideloaded address resources on this tenant — pick_address_parts() currently looks for type='addresses' and we need to confirm whether that's right.

= 0.0.17 =
* Fix: Dry Run's "Diagnostic detail (request + response)" disclosure was being wiped from the results panel whenever the dry run returned at least one row. Cause: renderDryRunResults() in admin.js was appending the disclosure to the container, then doing container.innerHTML = '' just before rendering the records table — which erased the disclosure along with everything else. The disclosure-only-shows-on-empty-results behavior had been there since v0.0.13 but went unnoticed because the original use case (debugging zero-row state-field probes) hit the empty path. Removed the redundant clear so the disclosure (and its top-line summary) remain alongside the results table.

= 0.0.16 =
* New: State / Province dropdown is now grouped by country. The United States is special-cased to the top with all US states listed under it; other countries follow alphabetically with their respective provinces/regions. Country names render in Initial Caps, states/provinces render in ALL CAPS — the case difference IS the visual hierarchy (HTML <option> elements can't accept indented styling reliably across browsers, so case carries the meaning). Selecting a country option filters by that country regardless of state; selecting a state option filters by that state.
* Schema: new `country` column on the people and staging tables. dbDelta runs automatically on the version bump (no manual migration). The column is empty for all existing rows until the next full sync repopulates it — until then the dropdown groups everything under "(Other)" at the bottom (still functional as a state filter, just no country headings).
* Sync: new pick_address_parts() (replaces the old pick_city_state) extracts country from the same usable address as city/state, with a fallback walk over country, country_name, country_code, country_iso, country_iso_code attribute names. The captured country is normalized through display_country_name() before being stored — "US", "USA", and "United States" all collapse to "United States" in the DB so equality filtering works without a synonym table.
* Filter logic: build_where() now takes a fifth filter (country); URL value cae_state=country:<NAME> is parsed server-side into a country-only filter, while a raw state value still filters by state. The two are mutually exclusive in the dropdown so this always disambiguates.
* Results summary picks up the country filter: "Showing 1 - 50 of 412 results matching country "Canada"" or compound forms like "name "smi", country "United States"".
* Note: re-sync required. The country column is empty until the next full sync runs (~19 minutes at default chunk settings). The dropdown will look correct after Sync Now completes and promotes staging to live.

= 0.0.15 =
* New: admin Settings -> Profile images checkbox (default: off). When unchecked, no person on the public roster shortcode displays a photo, and the photo column is omitted from the card layout entirely so the body fills the full width. The "Default photo" picker remains, but is only used when profile images are turned on and a person has no photo of their own.
* New: cumulative City and State/Province filters in the public search form. The form now has three inputs — Search by name (existing), City (open-ended text, partial match), and State / Province (dropdown populated from distinct values in the live roster). Any combination of the three may be used; none is required. Searching "Smi" + city "An" + state "NY" returns Mary Smith in Anytown NY and Bob Smithson in Annandale NY. The letter nav hides whenever any of these filters is active (the user has narrowed by other criteria); clicking Clear resets all three.
* Updated results-summary line for multi-filter searches: "Showing 1 - 50 of 78 results matching name "smi", city "an", state "NY"". The All/letter-mode wording ("results in All", "results in S") is unchanged.
* Card markup: an .is-no-photo class is applied when photos are off, which (a) avoids emitting the empty photo container, and (b) overrides the mobile center-aligned stack rule (designed for photo-above-body layout) back to natural left-aligned reading flow.

= 0.0.14 =
* New: unified results-summary line — "Showing X - Y of Z results in <nav>" for All/letter views, or "Showing X - Y of Z results matching "<term>"" for searches. Replaces the old "X matches for 'term'" search-only summary so all three navigation modes share a consistent pattern. Rendered both above the listing (with role=status so screen readers announce result-count changes) and above the pagination (when there's more than one page); centered to span the listing's full width.
* Fix: visible focus outline around the entire shortcode after a search or letter-nav click was still appearing despite the v0.0.13 reset. Root cause was a theme-level `[tabindex="-1"]:focus` rule that was tying with our reset on specificity and winning by load order — themes apply tabindex="-1" to landmark regions to make skip links land focus there. Switched the wrapper / search-form focus reset to `outline: none !important; box-shadow: none !important;` and added `[tabindex]` selector variants so the override unambiguously wins regardless of theme load order.

= 0.0.13 =
* New: "All" navigation item before "A" in the letter nav, and "All" is now the default landing view. Previously the shortcode defaulted to letter A, giving undue weight to people whose surnames started with that letter. The All view paginates across the entire roster using the same items-per-page count as letter views.
* Bumped default items per page 20 → 50, applies to both All and individual letter sections. One-time migration bumps existing installs that were still at the prior default; any value the user manually customised away from 20 is left alone.
* New: day-of-week checkboxes in the Scheduled sync settings. Pick any combination of Mon/Tue/Wed/.../Sun. If no days are selected, the scheduled sync is effectively turned off (manual Sync Now still works). One-time migration seeds existing installs with all 7 days so the upgrade preserves the prior daily behaviour.
* Architectural change to support day-of-week scheduling: switched from wp_schedule_event('daily', ...) to wp_schedule_single_event with a self-rearming pattern. After every scheduled run finalises, the next valid day+time is computed and queued. The next_run_timestamp() walker covers Sun-Sat and only returns a future slot. Day-of-week scheduling cannot be expressed in WP-Cron's built-in cadences; this is the right abstraction.
* Fix: an immediate fresh sync was kicking off seconds after the first one finished. Cause: the chunked sync was scheduling its successor chunk on the same hook (asae_cae_run_sync) used by the daily scheduled run. When the JS-driven Sync Now loop drove chunks faster than WP-Cron actually fired those events, queued events piled up. Once the run finalised and chunk_state was cleared, the queued events fired one by one — each finding no chunk_state, falling through run()'s "fresh start" branch, and starting a brand-new sync from page 1. Fix: split into two cron hooks (asae_cae_run_sync for scheduled runs, asae_cae_advance_chunk for chunk-advance), and every finalize_*() now calls clear_pending_and_reschedule() to drain orphaned chunk events before re-arming the next scheduled run.
* Fix: the public roster widget appeared with a visible focus outline around the entire shortcode after every letter click or search submit. Cause: a permissive ".asae-cae-roster *:focus-visible" selector that themes adding focus styling to the region wrapper or the search form (or a browser briefly focusing them on form submit) could trigger. Narrowed the selector to genuinely interactive descendants (a, button, input, select, textarea) and added a defensive outline:none on the wrapper and search form.
* Fix: card name rendered as "Firstname Lastname , CAE" with an extra space before the comma. Cause: HTML whitespace between adjacent inline elements (</strong> and <span>) collapses to a single space at render time. Output is now built as a single string with no inter-element whitespace.
* Wicket city/state extraction: expanded the field-name fallback list from {state, region} to also cover {state_name, province, province_name, state_province, country_subdivision, subdivision, administrative_area, state_code, province_code} — the Wicket platform is Canadian-based and may use international address conventions on this tenant. Added a diagnostic to dry-run output that surfaces the actual address attribute keys returned by the API, so if state still isn't extracting after the fallback expansion, the right field name is one click away.
* Accessibility: added explicit aria-label="Clear search and show entire roster" to the Clear link in the search form (it previously read as just "Clear" with no context). Letter nav aria-label updated from "Filter by last name initial" to "Filter by last name" since "All" is now part of the nav.

= 0.0.12 =
* Fix: chunked sync was getting "Run abandoned: chunk state stalled past the recovery threshold" overnight on local dev environments where WP-Cron's loopback to wp-cron.php is unreliable (Herd's NGINX/PHP-FPM, etc.). Lengthened ASAE_CAE_Sync::STALE_RUN_SECONDS from 30 minutes to 12 hours. The 30-minute threshold was treating "no traffic for 30 minutes" as a wedged run and aborting it; on hosts where cron events only fire when a page request happens, that threshold was incompatible with closed-laptop / inactive-tab gaps. 12 hours still cleans up genuine PHP-crash wreckage by morning, but lets a quiet-but-legit run resume the next time someone opens the dashboard. (Production hosts with steady frontend traffic were unaffected — this only bit local dev.)
* Browser tab throttling defense: when the Roster tab regains visibility (visibilitychange event), the admin JS immediately fires one progress poll and auto-resumes the chunk loop if a sync is still in progress. Chrome clamps setTimeout/setInterval to once-per-minute in tabs hidden longer than 5 minutes, which had been slowing the JS-driven chunk loop to a crawl when the user switched away. Tab-back now snaps it out of the throttle within one HTTP round-trip.
* Auto-resume from progress polling: if the polling tick sees a sync running and no JS chunk loop is currently driving it (e.g. user closed the laptop, came back, opened the dashboard fresh), the poller kicks off runChunkUntilDone automatically. Previously you had to click Sync Now again. A new chunkLoopActive flag prevents double-invocation when the poller and a manual click race.

= 0.0.11 =
* Sync Now now drives the entire chunked sync from the browser tab via repeated AJAX calls instead of relying on WP-Cron to fire each successive chunk. WP-Cron's loopback POST to wp-cron.php is unreliable on a lot of local dev environments (including Herd's NGINX/PHP-FPM out of the box), which had been leaving syncs stuck after the first chunk on those hosts. The JS-driven loop calls ajax_run_sync, waits the configured chunk_delay_seconds, and calls again — until the server reports in_progress=false. Wicket sees the same gentle one-page-every-5-seconds traffic pattern as before. The daily 02:00 sync still uses WP-Cron (which works fine in production WP environments).
* Added a short-lived transient chunk lock in Sync::run() so a JS-driven call and a cron-driven event can't accidentally race on the same Wicket page if both fire at once. TTL is 90 seconds — generous enough for slow API responses, short enough that a crashed PHP process can't keep the lock forever.
* Sync result payloads now include an `in_progress` flag based on whether chunk_state still exists after the call. Used by the JS loop to know when to stop calling.

= 0.0.10 =
* Dry Run now shows every record Wicket returned (up to the 50-record limit), not just the ones that pass validation. Each row has a Status column: green "Active" for records that would be inserted by a real sync, red "Hidden — <reason>" for ones that are filtered out. Reasons currently surface: deleted, anonymized, and "expired (end_date YYYY-MM-DD)". Skipped rows are also styled with strikethrough on the # and Name columns so they're visually obvious.
* Diagnostic top-line breaks the count into "active" + "hidden" instead of the older "passed structural validation" wording: e.g. "Wicket returned 50 record(s) · 45 active · 5 hidden · 2 API call(s)".
* Refactor: normalize_person() now always returns an array with a _skip_reason field instead of returning null on filter. Same effective behavior in the chunked sync (records with a non-empty reason are counted as skipped, not inserted) but lets dry_run keep them around for display.

= 0.0.9 =
* Fix: chunked sync stalled after the first chunk on sites in any timezone west of UTC. The recover_stale_runs() routine was parsing chunk_state.updated_at (which current_time('mysql') writes in LOCAL time) as if it were UTC, then comparing it to a cutoff that was also in UTC format. On America/New_York the result was that fresh state appeared 4 hours old — past the 30-minute staleness threshold — so every chunk after the first got incorrectly marked aborted and its successor unscheduled. Two-line fix: parse updated_at via DateTime::createFromFormat($fmt, $str, wp_timezone()) and format the SQL cutoff via wp_date() instead of gmdate().
* Fix: same timezone bug was making the Roster tab's "Last sync" timestamp and every Logs tab row display 4–5 hours off. Both views now use the new ASAE_CAE_Sync::mysql_local_to_timestamp() helper.
* Removed the misleading self-record probe from Dry Run diagnostics (added in v0.0.7 on the false premise that the configured Wicket person UUID would be a representative CAE — it's an API auth account, not a content sample). Baseline GET and filter probes remain.

= 0.0.8 =
* Production sync filter now uses two independent fields AND'd together: data_fields.designations.value.cae = true AND data_fields.designations.value.cae_type = "cae". Both returned the same 4,736-record count in the v0.0.7 diagnostic probes; AND-ing them costs nothing and acts as cross-validation against either field drifting in the future.
* Removed the server-side end_date_gteq filter. Wicket's search_query syntax does NOT support predicate suffixes (_eq, _gteq, etc.) on nested data_fields paths — the v0.0.7 probes confirmed this (the variant with `_eq` suffix returned 0 while the otherwise-identical implicit-equality variant returned 4,736). The "currently active CAE" date check is now performed client-side in normalize_person against designations.value.end_date.
* Trimmed Check for Updates "no releases" message from a multi-line tutorial to "No releases found." Diagnostic detail removed from the routine UX path.

= 0.0.7 =
* Check for Updates now distinguishes "no GitHub releases tagged yet" (cure-able by `git tag vX.Y.Z && git push origin vX.Y.Z`) from "couldn't reach api.github.com." Settings tab message is actionable instead of misleading.
* Dry Run is now self-debugging when the primary filter returns zero. After the existing baseline GET probe, it also runs (a) a "self-record" probe that fetches the configured Wicket person UUID's own /people/{uuid} record and shows the actual data_fields keys + the full designations entry, and (b) six filter-variant probes (no filter, status_eq only, four different data_fields path/predicate combinations) and reports total_items for each. Whichever variant returns >0 is the syntax we should use. Net result: one click pinpoints exactly which path/predicate Wicket honors, no further code-iteration guessing.
* The probes are diagnostic only; they fire only when the primary filter returns zero, so a working dry run still costs one API call.

= 0.0.6 =
* Check for Updates Now now reports its findings inline (matches asae-content-ingestor's pattern). When a newer release is found on GitHub the Settings tab shows "Update available: vX.Y.Z — Go to Plugins page" in red with a working link; otherwise it shows "You are running the latest version (vX.Y.Z)" in green. The previous behavior — generic "Update check complete, refresh the Plugins page" — gave no signal whether anything was actually pending.
* Made ASAE_CAE_GitHub_Updater::get_latest_release() public so the Check for Updates handler can compare current to remote.
* Dry Run output now includes a "Diagnostic detail" disclosure with the exact JSON request body, response top-level keys, response meta, and a baseline GET /people probe that runs automatically when the primary filter returns zero. Lets us see whether the filter is rejecting matches or the tenant has no data, without further code iteration.

= 0.0.5 =
* Switched to Wicket's POST /people/query endpoint (per https://wicketapi.docs.apiary.io/) so we can filter on nested data_fields paths server-side. The new query selects on `data_fields.designations.value.cae = true` AND `data_fields.designations.value.end_date_gteq = today` — which is what "currently-active CAE" actually means. The old GET filter[tag_eq]=CAE never matched (tags is an array attribute, not a scalar) and `attributes.status === active` describes ASAE membership, not CAE certification.
* Added request_post() to the Wicket client. Shares JWT auth, request budget, courtesy delay, and exponential-backoff retry with the existing GET request() via a common dispatcher.
* Loosened normalize_person: hard rejects only on deleted_at / anonymized_at. The CAE-active validation that used to reject every record when the response trimmed data_fields is now satisfied upstream by the server-side filter.
* Dry Run output now shows a diagnostic line: how many records Wicket returned, how many passed structural validation, and how many API calls were made — so a future "0 records" issue is debuggable in one click instead of guesswork.

= 0.0.4 =
* Sync is now broken into many small WP-Cron-driven chunks instead of one long blocking call. Each chunk fetches a small number of Wicket pages (default 1 page = 25 records) and self-schedules the next chunk after a configurable delay (default 5s). Resumable across PHP-process boundaries; live data isn't promoted until every chunk is complete. Fixes the "Per-run request budget reached (500)" failure mode for rosters of ~5,000 CAEs.
* New "Dry Run (Preview First 50)" admin action — fetches the first 50 active CAEs alphabetically (sort=family_name) and renders them in a table on the Roster tab. No DB writes, no effect on the live or staging tables.
* Plugin version moved from the Roster tab's status table to a small badge next to the page title, visible on every tab (matches the convention used by other ASAE plugins).
* "Check for Updates Now" moved from the Roster tab to the Settings tab, again matching the convention used by other ASAE plugins.
* Added two new Settings fields under "Chunked sync": Pages per chunk (default 1) and Delay between chunks in seconds (default 5). The existing "Max requests per chunk" / "Delay between requests" labels were clarified to indicate they're now per-chunk caps.
* Stop All Active Jobs now also clears the in-progress chunk state and unschedules any pending single-event chunks — so a stopped run truly stops, even if a chunk was queued to fire seconds later.
* Stale-run recovery now uses chunk_state.updated_at instead of started_at, so a healthy chunked sync that runs longer than 30 minutes isn't mistakenly aborted.

= 0.0.3 =
* Photos are no longer sideloaded into the WordPress media library. Sync stores the remote Wicket photo URL only; the public shortcode renders each <img> with native lazy-loading and a data-fallback attribute. A small client-side handler swaps the src to the admin-configured default photo when a remote image returns 404 or otherwise fails to load. This eliminates ~5,000 image downloads per sync and ~5,000 attachment rows per snapshot.
* Added a live progress meter to the Roster tab, mirroring the Group Rosters plugin: progress bar, "X of Y — phase" headline, and a sub-status line for the current record. Powered by a polled AJAX endpoint that reads a snapshot wp_options row written by the sync at every phase boundary and every 10 records.
* Concurrency guard: Sync::run() refuses to start when another sync is already running, with auto-recovery for stale 'running' rows older than 30 minutes (e.g. PHP crashed mid-run).

= 0.0.2 =
* Added "Stop All Active Jobs" admin action on the Roster tab. Sets a cooperative kill flag the running sync polls per-record, then marks any in-progress log rows as aborted and discards the staging table. Live roster is never touched, so readers continue to see the last good snapshot.

= 0.0.1 =
* Initial release
* Wicket API client with HMAC JWT auth, request budget, and exponential backoff
* Stage-and-swap sync with automatic revert on failure
* Daily WP-Cron sync at configurable local time
* Tabbed admin UI (Roster status / Settings / Logs)
* Public `[asae_cae_roster]` shortcode with letter nav, search, pagination
* WCAG 2.2 AA accessibility audit pass
* Self-hosted GitHub Releases updater
